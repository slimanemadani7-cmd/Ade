plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dz.ade.mission"
    compileSdk = 35

    defaultConfig {
        applicationId = "dz.ade.mission"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
